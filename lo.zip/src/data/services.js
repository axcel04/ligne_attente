export const services = [
  { id: 1, name: "Consultation Générale", icon: "" },
  { id: 2, name: "Radiologie" , icon: ""  },
  { id: 3, name: "Laboratoire" , icon: "" },
  { id: 4, name: "Pédiatrie" , icon: ""  },
];
